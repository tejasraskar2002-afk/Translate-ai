package com.example.marathi2english

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var translation: TextView
    private lateinit var recordButton: Button
    private lateinit var translateButton: Button
    private lateinit var progress: ProgressBar
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val transcriptParts = StringBuilder()
    private val maxRecordingMs = 120_000L

    private val stopRecording = Runnable {
        if (isListening) stopListening()
        status.text = "रेकॉर्डिंगची 2 मिनिटांची मर्यादा पूर्ण झाली."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "या मोबाईलवर speech recognition सेवा उपलब्ध नाही."
            recordButton.isEnabled = false
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF7F9FC.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val title = TextView(this).apply {
            text = "Marathi2English AI"
            textSize = 26f
            setTextColor(0xFF123B73.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "मराठीत बोला • नैसर्गिक इंग्रजी मिळवा"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 22)
        }
        status = TextView(this).apply {
            text = "रेकॉर्डिंग सुरू करण्यासाठी बटण दाबा."
            textSize = 14f
            setPadding(0, 8, 0, 12)
        }
        recordButton = Button(this).apply {
            text = "🎙 मराठीत बोला (कमाल 2 मिनिटे)"
            setOnClickListener {
                if (isListening) stopListening() else checkPermissionAndStart()
            }
        }
        progress = ProgressBar(this).apply {
            visibility = View.GONE
        }
        val transcriptTitle = sectionTitle("तुमचा मराठी मजकूर")
        transcript = bodyText("तुमचा आवाज इथे मजकूर म्हणून दिसेल.")
        translateButton = Button(this).apply {
            text = "इंग्रजीत भाषांतर करा"
            isEnabled = false
            setOnClickListener { translateText() }
        }
        val translationTitle = sectionTitle("Natural English Translation")
        translation = bodyText("इंग्रजी भाषांतर इथे दिसेल.")
        val copyButton = Button(this).apply {
            text = "भाषांतर कॉपी करा"
            setOnClickListener {
                val clip = android.content.ClipData.newPlainText("English translation", translation.text)
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
                Toast.makeText(this@MainActivity, "भाषांतर कॉपी झाले.", Toast.LENGTH_SHORT).show()
            }
        }
        val note = TextView(this).apply {
            text = "टीप: आवाज ओळखण्यासाठी मोबाईलवरील speech service आणि भाषांतरासाठी इंटरनेट आवश्यक आहे. संवेदनशील किंवा खाजगी मजकूर पाठवण्यापूर्वी काळजी घ्या."
            textSize = 12f
            setTextColor(0xFF5F6875.toInt())
            setPadding(0, 20, 0, 8)
        }

        listOf(title, subtitle, status, recordButton, progress, transcriptTitle, transcript,
            translateButton, translationTitle, translation, copyButton, note).forEach {
            content.addView(it, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 10 })
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 18f
        setTextColor(0xFF123B73.toInt())
        setPadding(0, 16, 0, 4)
    }

    private fun bodyText(value: String) = TextView(this).apply {
        text = value
        textSize = 16f
        setTextColor(0xFF202833.toInt())
        setPadding(14, 14, 14, 14)
        setBackgroundColor(0xFFFFFFFF.toInt())
    }

    private fun checkPermissionAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 201)
        } else startListening()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 201 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            status.text = "आवाज रेकॉर्ड करण्यासाठी microphone permission आवश्यक आहे."
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition उपलब्ध नाही. Google app/भाषा सेवा तपासा."
            return
        }
        transcriptParts.clear()
        transcript.text = ""
        translation.text = ""
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    status.text = "ऐकत आहे… मराठीत बोला."
                    isListening = true
                    recordButton.text = "⏹ रेकॉर्डिंग थांबवा"
                    progress.visibility = View.VISIBLE
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    isListening = false
                    recordButton.text = "🎙 पुन्हा रेकॉर्ड करा"
                    progress.visibility = View.GONE
                }
                override fun onError(error: Int) {
                    isListening = false
                    handler.removeCallbacks(stopRecording)
                    recordButton.text = "🎙 पुन्हा रेकॉर्ड करा"
                    progress.visibility = View.GONE
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "आवाज समजला नाही. पुन्हा प्रयत्न करा."
                        SpeechRecognizer.ERROR_NETWORK -> "Speech service साठी इंटरनेट तपासा."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission द्या."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service व्यस्त आहे. थोड्या वेळाने प्रयत्न करा."
                        else -> "आवाज ओळखताना त्रुटी आली (code $error). पुन्हा प्रयत्न करा."
                    }
                    status.text = msg
                    translateButton.isEnabled = transcript.text.isNotBlank()
                }
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val recognized = matches?.firstOrNull().orEmpty()
                    if (recognized.isNotBlank()) {
                        if (transcriptParts.isNotEmpty()) transcriptParts.append(" ")
                        transcriptParts.append(recognized)
                        transcript.text = transcriptParts.toString()
                    }
                    isListening = false
                    handler.removeCallbacks(stopRecording)
                    recordButton.text = "🎙 पुन्हा रेकॉर्ड करा"
                    progress.visibility = View.GONE
                    status.text = if (transcript.text.isNotBlank()) "आवाज मजकुरात रूपांतरित झाला." else "मजकूर मिळाला नाही. पुन्हा प्रयत्न करा."
                    translateButton.isEnabled = transcript.text.isNotBlank()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    matches?.firstOrNull()?.let { transcript.text = if (transcriptParts.isEmpty()) it else "${transcriptParts} $it" }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "mr-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            }
            recognizer.startListening(intent)
        }
        handler.removeCallbacks(stopRecording)
        handler.postDelayed(stopRecording, maxRecordingMs)
        isListening = true
        recordButton.text = "⏹ रेकॉर्डिंग थांबवा"
    }

    private fun stopListening() {
        handler.removeCallbacks(stopRecording)
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        isListening = false
        recordButton.text = "🎙 पुन्हा रेकॉर्ड करा"
        progress.visibility = View.GONE
        status.text = "रेकॉर्डिंग थांबवले. मजकूर पूर्ण होण्यासाठी क्षणभर थांबा."
    }

    private fun translateText() {
        val source = transcript.text.toString().trim()
        if (source.isBlank() || source.startsWith("तुमचा आवाज")) {
            Toast.makeText(this, "आधी मराठीत आवाज रेकॉर्ड करा.", Toast.LENGTH_SHORT).show()
            return
        }
        status.text = "इंग्रजी भाषांतर तयार होत आहे…"
        progress.visibility = View.VISIBLE
        translateButton.isEnabled = false
        executor.execute {
            try {
                val query = URLEncoder.encode(source, "UTF-8")
                val url = URL("https://api.mymemory.translated.net/get?q=$query&langpair=mr|en")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("User-Agent", "Marathi2EnglishAI/1.0")
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                connection.disconnect()
                val json = JSONObject(response)
                val translated = json.optJSONObject("responseData")?.optString("translatedText").orEmpty()
                if (translated.isBlank()) throw Exception("भाषांतर रिकामे आले.")
                runOnUiThread {
                    translation.text = translated
                    status.text = "भाषांतर पूर्ण झाले. अचूकतेसाठी एकदा तपासा."
                    progress.visibility = View.GONE
                    translateButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "भाषांतर झाले नाही. इंटरनेट तपासा आणि पुन्हा प्रयत्न करा."
                    progress.visibility = View.GONE
                    translateButton.isEnabled = true
                    Toast.makeText(this, e.message ?: "Translation error", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(stopRecording)
        speechRecognizer?.destroy()
        executor.shutdownNow()
        super.onDestroy()
    }
}
