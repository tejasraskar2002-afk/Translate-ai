# Marathi2English AI — Professional Android Starter

Features:
- Android speech recognition requested in Marathi (`mr-IN`).
- Two-minute stop timer (actual recognition duration depends on the phone's speech service).
- Marathi-to-English translation via MyMemory public endpoint.
- English grammar/spelling suggestions via LanguageTool public API.
- Editable source and output, plus copy button.
- Demo sentence prefilled: “मला विद्यार्थ्यांना इंग्रजी व्याकरण शिकवायचे आहे.”

Expected English: “I want to teach English grammar to students.”

Limitations and privacy:
- This is Android Studio source code, not a ready-to-install APK.
- Public endpoints may have rate limits, availability changes, and language-quality limitations. Review provider terms before deployment.
- Speech services may stop early after pauses or return one segment only; the timer does not guarantee a continuous two-minute transcript.
- Text is sent to external online services. Do not use confidential content.
- Grammar suggestions do not guarantee fully professional wording or preserved meaning; review the final result.
- For production, use a controlled backend, disclose data handling, and protect any API credentials. Do not embed secret keys in an Android app.

Build:
1. Install Android Studio, JDK 17, and Android SDK Platform 35.
2. Extract the ZIP and open this folder in Android Studio.
3. Wait for Gradle sync; install any prompted SDK components.
4. Connect an Android phone with USB debugging enabled, or use a compatible emulator.
5. Press Run and allow microphone permission.
6. Ensure internet and a speech recognition service are available.

Flow: Record Marathi → review transcript → translate to English → correct grammar → copy.
