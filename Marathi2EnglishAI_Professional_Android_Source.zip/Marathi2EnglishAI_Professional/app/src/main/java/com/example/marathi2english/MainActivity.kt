package com.example.marathi2english

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var source: EditText
    private lateinit var english: EditText
    private lateinit var recordButton: Button
    private lateinit var translateButton: Button
    private lateinit var correctButton: Button
    private lateinit var progress: ProgressBar
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val maxRecordingMs = 120_000L
    private val stopTimer = Runnable {
        if (listening) stopListening()
        status.text = "2 मिनिटांची मर्यादा पूर्ण झाली. मजकूर तपासा."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "या फोनवर speech recognition सेवा उपलब्ध नाही."
            recordButton.isEnabled = false
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 20)
            setBackgroundColor(0xFFF6F8FC.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "Marathi2English AI"; textSize = 27f; gravity = Gravity.CENTER
            setTextColor(0xFF123B73.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "मराठीत बोला • Professional English मिळवा"
            textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 8, 0, 18)
        }
        status = TextView(this).apply {
            text = "रेकॉर्ड करा किंवा खालील डेमो मजकूर वापरा."
            textSize = 14f; setPadding(0, 8, 0, 8)
        }
        recordButton = Button(this).apply {
            text = "🎙 मराठीत बोला (कमाल 2 मिनिटे)"
            setOnClickListener { if (listening) stopListening() else requestMicAndStart() }
        }
        progress = ProgressBar(this).apply { visibility = View.GONE }
        val sourceTitle = sectionTitle("1. मराठी मजकूर")
        source = editText("तुमचा मराठी मजकूर येथे दिसेल.")
        source.setText("मला विद्यार्थ्यांना इंग्रजी व्याकरण शिकवायचे आहे.")
        translateButton = Button(this).apply {
            text = "मराठीतून इंग्रजीत भाषांतर करा"
            setOnClickListener { translateMarathi() }
        }
        val englishTitle = sectionTitle("2. English Translation")
        english = editText("इंग्रजी भाषांतर येथे दिसेल.")
        correctButton = Button(this).apply {
            text = "English Grammar व Writing दुरुस्त करा"
            setOnClickListener { correctEnglish() }
        }
        val copyButton = Button(this).apply {
            text = "इंग्रजी कॉपी करा"
            setOnClickListener {
                val value = english.text.toString().trim()
                if (value.isBlank()) Toast.makeText(this@MainActivity, "आधी इंग्रजी मजकूर तयार करा.", Toast.LENGTH_SHORT).show()
                else {
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("English", value))
                    Toast.makeText(this@MainActivity, "इंग्रजी मजकूर कॉपी झाला.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val note = TextView(this).apply {
            text = "भाषांतरानंतर Grammar दुरुस्ती चालवा. इंटरनेट आवश्यक आहे. मजकूर बाह्य ऑनलाइन सेवांकडे पाठवला जातो; गोपनीय माहिती वापरू नका."
            textSize = 12f; setTextColor(0xFF5B6472.toInt()); setPadding(0, 14, 0, 8)
        }
        listOf(title, subtitle, status, recordButton, progress, sourceTitle, source,
            translateButton, englishTitle, english, correctButton, copyButton, note).forEach {
            content.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value; textSize = 18f; setTextColor(0xFF123B73.toInt()); setPadding(0, 12, 0, 5)
    }

    private fun editText(value: String) = EditText(this).apply {
        setText(value); textSize = 16f; minLines = 3; gravity = Gravity.TOP
        setPadding(14, 12, 14, 12); setBackgroundColor(0xFFFFFFFF.toInt())
    }

    private fun requestMicAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 201)
        else startListening()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 201 && results.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
        else status.text = "आवाजासाठी microphone permission आवश्यक आहे."
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition उपलब्ध नाही. Google speech service तपासा."; return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                status.text = "ऐकत आहे… मराठीत स्पष्ट बोला."
                listening = true; recordButton.text = "⏹ रेकॉर्डिंग थांबवा"; progress.visibility = View.VISIBLE
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false; recordButton.text = "🎙 पुन्हा रेकॉर्ड करा"; progress.visibility = View.GONE }
            override fun onError(error: Int) {
                listening = false; handler.removeCallbacks(stopTimer)
                recordButton.text = "🎙 पुन्हा रेकॉर्ड करा"; progress.visibility = View.GONE
                status.text = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "आवाज समजला नाही. पुन्हा प्रयत्न करा."
                    SpeechRecognizer.ERROR_NETWORK -> "Speech service साठी इंटरनेट तपासा."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission द्या."
                    else -> "Speech recognition त्रुटी (code $error). पुन्हा प्रयत्न करा."
                }
            }
            override fun onResults(results: Bundle?) {
                val result = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (result.isNotBlank()) source.setText(result)
                listening = false; handler.removeCallbacks(stopTimer)
                recordButton.text = "🎙 पुन्हा रेकॉर्ड करा"; progress.visibility = View.GONE
                status.text = if (result.isBlank()) "मजकूर मिळाला नाही. पुन्हा प्रयत्न करा." else "आवाज मजकुरात बदलला. आता भाषांतर करा."
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!p.isNullOrBlank()) status.text = "ऐकत आहे… $p"
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "mr-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
        }
        recognizer?.startListening(intent)
        listening = true
        handler.removeCallbacks(stopTimer); handler.postDelayed(stopTimer, maxRecordingMs)
    }

    private fun stopListening() {
        handler.removeCallbacks(stopTimer)
        try { recognizer?.stopListening() } catch (_: Exception) {}
        listening = false; recordButton.text = "🎙 पुन्हा रेकॉर्ड करा"
        status.text = "रेकॉर्डिंग थांबवले. मजकूर तयार होण्यासाठी थांबा."
    }

    private fun translateMarathi() {
        val text = source.text.toString().trim()
        if (text.isBlank()) { Toast.makeText(this, "मराठी मजकूर टाका किंवा आवाज रेकॉर्ड करा.", Toast.LENGTH_SHORT).show(); return }
        busy("Professional English भाषांतर तयार होत आहे…")
        worker.execute {
            try {
                val query = URLEncoder.encode(text, "UTF-8")
                val url = URL("https://api.mymemory.translated.net/get?q=$query&langpair=mr|en")
                val c = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"; connectTimeout = 15000; readTimeout = 20000
                    setRequestProperty("User-Agent", "Marathi2EnglishAI/2.0")
                }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }; c.disconnect()
                val result = JSONObject(response).optJSONObject("responseData")?.optString("translatedText").orEmpty()
                if (result.isBlank()) throw Exception("रिकामे भाषांतर")
                runOnUiThread { english.setText(result); idle("भाषांतर झाले. आता Grammar दुरुस्ती चालवा.") }
            } catch (_: Exception) { runOnUiThread { idle("भाषांतर झाले नाही. इंटरनेट किंवा translation service तपासा.") } }
        }
    }

    private fun correctEnglish() {
        val text = english.text.toString().trim()
        if (text.isBlank()) { Toast.makeText(this, "आधी इंग्रजी भाषांतर करा किंवा मजकूर पेस्ट करा.", Toast.LENGTH_SHORT).show(); return }
        busy("Grammar आणि spelling तपासत आहे…")
        worker.execute {
            try {
                val body = "text=${URLEncoder.encode(text, "UTF-8")}&language=en-US"
                val c = (URL("https://api.languagetool.org/v2/check").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; doOutput = true; connectTimeout = 15000; readTimeout = 25000
                    setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                    setRequestProperty("User-Agent", "Marathi2EnglishAI/2.0")
                }
                OutputStreamWriter(c.outputStream, Charsets.UTF_8).use { it.write(body) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }; c.disconnect()
                val fixed = applySuggestions(text, JSONObject(response))
                runOnUiThread { english.setText(fixed); idle("Grammar तपासणी पूर्ण. अंतिम मजकूर स्वतःही तपासा.") }
            } catch (_: Exception) { runOnUiThread { idle("Grammar सेवा उपलब्ध नाही. इंटरनेट तपासा किंवा नंतर प्रयत्न करा.") } }
        }
    }

    private fun applySuggestions(original: String, json: JSONObject): String {
        val matches = json.optJSONArray("matches") ?: return original
        data class Fix(val offset: Int, val length: Int, val replacement: String)
        val fixes = mutableListOf<Fix>()
        for (i in 0 until matches.length()) {
            val m = matches.optJSONObject(i) ?: continue
            val replacements = m.optJSONArray("replacements") ?: continue
            if (replacements.length() == 0) continue
            val replacement = replacements.optJSONObject(0)?.optString("value") ?: continue
            fixes.add(Fix(m.optInt("offset"), m.optInt("length"), replacement))
        }
        val result = StringBuilder(original)
        fixes.sortedByDescending { it.offset }.forEach {
            if (it.offset >= 0 && it.offset + it.length <= result.length)
                result.replace(it.offset, it.offset + it.length, it.replacement)
        }
        return result.toString()
    }

    private fun busy(message: String) {
        status.text = message; progress.visibility = View.VISIBLE
        translateButton.isEnabled = false; correctButton.isEnabled = false
    }
    private fun idle(message: String) {
        status.text = message; progress.visibility = View.GONE
        translateButton.isEnabled = true; correctButton.isEnabled = true
    }
    override fun onDestroy() {
        handler.removeCallbacks(stopTimer); recognizer?.destroy(); worker.shutdownNow(); super.onDestroy()
    }
}
